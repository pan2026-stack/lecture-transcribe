"""没有外部守护进程时，出网失败不能导致本地服务退出。"""
import os
import pathlib
import socket
import subprocess
import sys
import time
import urllib.request

root = pathlib.Path(__file__).resolve().parent.parent
py = sys.executable
port = 8891

env = dict(os.environ)
env['DICT_PROBE_SECONDS'] = '2'        # 测试时 2 秒探一次
env['DICT_PROBE_FAILS'] = '2'          # 连续 2 次就触发
env.pop('DICT_SUPERVISED', None)
env['DICT_PROBE_TARGET'] = 'http://127.0.0.1:9'   # 必定失败的端口

proc = subprocess.Popen([py, 'server.py', '--port', str(port)], cwd=str(root),
                        env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        text=True, encoding='utf-8', errors='ignore')

# 等服务起来
for _ in range(20):
    time.sleep(0.5)
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/config', timeout=2) as r:
            assert r.status == 200
        break
    except Exception:
        continue
else:
    print('服务没起来')
    proc.kill()
    raise SystemExit(1)

print('服务已启动，验证外网失败时仍能响应…')
try:
    time.sleep(7)
    assert proc.poll() is None, f'服务意外退出 {proc.returncode}'
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/ping', timeout=3) as r:
        assert r.status == 200
    print('通过：服务保持存活，ping 正常')
finally:
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
